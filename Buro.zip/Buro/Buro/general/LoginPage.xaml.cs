﻿using Buro.Employer;
using Buro.JobSeeker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro.general
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        private MainWindow _mainWindow;
        private bool _isPasswordVisible = false;
        private TextBox _passwordTextBox;

        public LoginPage(MainWindow mainWindow)
        {
            InitializeComponent();
            _mainWindow = mainWindow;

            // Настройка обработчиков событий
            LoginEmailTextBox.TextChanged += (s, e) => HideMessage();

            // Инициализация кнопки показа пароля
            UpdatePasswordToggleButton();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            _mainWindow.NavigateToMainPage();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginEmailTextBox.Text.Trim();
            string password = GetPassword();

            // Валидация
            if (string.IsNullOrWhiteSpace(login))
            {
                ShowMessage("Введите логин или email", true);
                LoginEmailTextBox.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                ShowMessage("Введите пароль", true);
                if (_isPasswordVisible && _passwordTextBox != null)
                    _passwordTextBox.Focus();
                else
                    LoginPasswordBox.Focus();
                return;
            }

            // Проверка типа пользователя (временная логика)
            if (login.ToLower() == "admin" && password == "admin123")
            {
                // Администратор
                ShowMessage("Вход выполнен успешно! Добро пожаловать, администратор!", false);
                _mainWindow.MainFrame.Navigate(new Admin.AdminDashboard(_mainWindow, "Администратор"));
            }
            else if (login.Contains("@company") || login.Contains("employer"))
            {
                // Работодатель
                ShowMessage("Вход выполнен успешно! Добро пожаловать, работодатель!", false);
                _mainWindow.MainFrame.Navigate(new EmployerDashboard(_mainWindow, "TechCorp Inc."));
            }
            else
            {
                // Соискатель
                ShowMessage("Вход выполнен успешно! Добро пожаловать, соискатель!", false);
                _mainWindow.MainFrame.Navigate(new JobSeekerDashboard(_mainWindow, "Иван Иванов"));
            }
        }

        private string GetPassword()
        {
            if (_isPasswordVisible && _passwordTextBox != null)
                return _passwordTextBox.Text;
            else
                return LoginPasswordBox.Password;
        }

        private void ClearPassword()
        {
            if (_isPasswordVisible && _passwordTextBox != null)
                _passwordTextBox.Clear();
            else
                LoginPasswordBox.Clear();
        }

        private bool CheckCredentials(string login, string password)
        {
            // Временная логика для демонстрации
            // В реальном приложении здесь должна быть проверка в базе данных

            // Демонстрационные учетные записи
            if (login.ToLower() == "admin" && password == "admin123")
                return true;

            if (login.ToLower() == "user@example.com" && password == "password123")
                return true;

            if (login.ToLower() == "company@example.com" && password == "company123")
                return true;

            return false;
        }

        private string GetUserName(string login)
        {
            // Временная логика для демонстрации
            if (login.ToLower() == "admin")
                return "Администратор";

            if (login.ToLower() == "user@example.com")
                return "Соискатель";

            if (login.ToLower() == "company@example.com")
                return "Компания";

            return "Пользователь";
        }

        private void ShowMessage(string message, bool isError)
        {
            LoginMessageTextBlock.Text = message;
            MessageBorder.Visibility = Visibility.Visible;

            if (isError)
            {
                MessageBorder.BorderBrush = new SolidColorBrush(Color.FromRgb(244, 67, 54)); // Красный
                LoginMessageTextBlock.Foreground = new SolidColorBrush(Color.FromRgb(244, 67, 54));
            }
            else
            {
                MessageBorder.BorderBrush = new SolidColorBrush(Color.FromRgb(46, 125, 50)); // Зеленый
                LoginMessageTextBlock.Foreground = new SolidColorBrush(Color.FromRgb(46, 125, 50));
            }
        }

        private void HideMessage()
        {
            MessageBorder.Visibility = Visibility.Collapsed;
        }

        private void RegisterRedirect_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            _mainWindow.MainFrame.Navigate(new RegisterPage(_mainWindow));
        }

        private void TogglePasswordButton_Click(object sender, RoutedEventArgs e)
        {
            _isPasswordVisible = !_isPasswordVisible;
            UpdatePasswordToggleButton();
        }

        private void UpdatePasswordToggleButton()
        {
            if (_isPasswordVisible)
            {
                // Показываем пароль (заменяем PasswordBox на TextBox)
                var passwordBox = LoginPasswordBox;
                var textBox = new TextBox
                {
                    Text = passwordBox.Password,
                    FontSize = passwordBox.FontSize,
                    Padding = passwordBox.Padding,
                    Background = passwordBox.Background,
                    Foreground = new SolidColorBrush(Color.FromRgb(204, 204, 204)),
                    BorderBrush = passwordBox.BorderBrush,
                    BorderThickness = passwordBox.BorderThickness,
                    Height = passwordBox.Height,
                    VerticalAlignment = VerticalAlignment.Center,
                    CaretBrush = new SolidColorBrush(Color.FromRgb(13, 115, 119))
                };

                // Добавляем обработчик изменения текста
                textBox.TextChanged += (s, e) => HideMessage();

                // Заменяем PasswordBox на TextBox
                var grid = (Grid)passwordBox.Parent;
                var column = Grid.GetColumn(passwordBox);

                grid.Children.Remove(passwordBox);
                Grid.SetColumn(textBox, column);
                grid.Children.Add(textBox);

                // Сохраняем ссылку на TextBox
                _passwordTextBox = textBox;

                // Обновляем кнопку
                ((TextBlock)TogglePasswordButton.Content).Text = "🙈";
            }
            else
            {
                // Скрываем пароль (возвращаем PasswordBox)
                if (_passwordTextBox != null)
                {
                    var grid = (Grid)_passwordTextBox.Parent;
                    var column = Grid.GetColumn(_passwordTextBox);

                    grid.Children.Remove(_passwordTextBox);

                    var passwordBox = new PasswordBox
                    {
                        Password = _passwordTextBox.Text,
                        FontSize = _passwordTextBox.FontSize,
                        Padding = _passwordTextBox.Padding,
                        Background = _passwordTextBox.Background,
                        BorderBrush = _passwordTextBox.BorderBrush,
                        BorderThickness = _passwordTextBox.BorderThickness,
                        Height = _passwordTextBox.Height,
                        VerticalAlignment = VerticalAlignment.Center
                    };

                    // Добавляем обработчик изменения пароля
                    passwordBox.PasswordChanged += (s, e) => HideMessage();

                    Grid.SetColumn(passwordBox, column);
                    grid.Children.Add(passwordBox);

                    // Сохраняем ссылку на PasswordBox
                    LoginPasswordBox = passwordBox;
                    _passwordTextBox = null;

                    // Обновляем кнопку
                    ((TextBlock)TogglePasswordButton.Content).Text = "👁️";
                }
            }
        }
    }
}
