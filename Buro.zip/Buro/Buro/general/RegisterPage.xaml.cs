﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro.general
{
    /// <summary>
    /// Логика взаимодействия для RegisterPage.xaml
    /// </summary>
    public partial class RegisterPage : Page
    {
        private MainWindow _mainWindow;
        private bool _isPasswordVisible = false;
        private bool _isConfirmPasswordVisible = false;
        private bool _isCompanyPasswordVisible = false;
        private bool _isCompanyConfirmPasswordVisible = false;
        private TextBox _passwordTextBox;
        private TextBox _confirmPasswordTextBox;
        private TextBox _companyPasswordTextBox;
        private TextBox _companyConfirmPasswordTextBox;

        public RegisterPage(MainWindow mainWindow)
        {
            InitializeComponent();
            _mainWindow = mainWindow;
            SetupEventHandlers();
        }

        private void SetupEventHandlers()
        {
            JobSeekerRadio.Checked += (s, e) => ShowJobSeekerForm();
            EmployerRadio.Checked += (s, e) => ShowEmployerForm();

            // Подписываемся на события изменения текста для скрытия сообщений
            FullNameTextBox.TextChanged += (s, e) => HideMessage();
            EmailTextBox.TextChanged += (s, e) => HideMessage();
            PhoneTextBox.TextChanged += (s, e) => HideMessage();
            ProfessionTextBox.TextChanged += (s, e) => HideMessage();
            ExperienceTextBox.TextChanged += (s, e) => HideMessage();
            EducationTextBox.TextChanged += (s, e) => HideMessage();

            CompanyNameTextBox.TextChanged += (s, e) => HideMessage();
            InnTextBox.TextChanged += (s, e) => HideMessage();
            CompanyEmailTextBox.TextChanged += (s, e) => HideMessage();
            CompanyPhoneTextBox.TextChanged += (s, e) => HideMessage();
            ContactPersonTextBox.TextChanged += (s, e) => HideMessage();
            BusinessFieldTextBox.TextChanged += (s, e) => HideMessage();
        }

        private void ShowJobSeekerForm()
        {
            JobSeekerForm.Visibility = Visibility.Visible;
            EmployerForm.Visibility = Visibility.Collapsed;
            HideMessage();
        }

        private void ShowEmployerForm()
        {
            JobSeekerForm.Visibility = Visibility.Collapsed;
            EmployerForm.Visibility = Visibility.Visible;
            HideMessage();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            _mainWindow.NavigateToMainPage();
        }

        private void RegisterSubmitButton_Click(object sender, RoutedEventArgs e)
        {
            if (JobSeekerRadio.IsChecked == true)
            {
                RegisterJobSeeker();
            }
            else
            {
                RegisterEmployer();
            }
        }

        private void RegisterJobSeeker()
        {
            // Проверка заполнения обязательных полей
            if (string.IsNullOrWhiteSpace(FullNameTextBox.Text))
            {
                ShowMessage("Введите ФИО", true);
                FullNameTextBox.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(EmailTextBox.Text))
            {
                ShowMessage("Введите Email", true);
                EmailTextBox.Focus();
                return;
            }

            if (!IsValidEmail(EmailTextBox.Text))
            {
                ShowMessage("Введите корректный Email", true);
                EmailTextBox.Focus();
                EmailTextBox.SelectAll();
                return;
            }

            string password = GetJobSeekerPassword();
            string confirmPassword = GetJobSeekerConfirmPassword();

            if (string.IsNullOrWhiteSpace(password))
            {
                ShowMessage("Введите пароль", true);
                FocusJobSeekerPassword();
                return;
            }

            if (password.Length < 6)
            {
                ShowMessage("Пароль должен содержать минимум 6 символов", true);
                FocusJobSeekerPassword();
                return;
            }

            if (password != confirmPassword)
            {
                ShowMessage("Пароли не совпадают", true);
                FocusJobSeekerConfirmPassword();
                return;
            }

            if (string.IsNullOrWhiteSpace(ProfessionTextBox.Text))
            {
                ShowMessage("Введите профессию", true);
                ProfessionTextBox.Focus();
                return;
            }

            // Все проверки пройдены
            // Здесь должна быть логика сохранения в базу данных

            ShowMessage($"Соискатель {FullNameTextBox.Text} успешно зарегистрирован!", false);

            // Задержка перед переходом на страницу входа
            Task.Delay(1500).ContinueWith(_ =>
            {
                Dispatcher.Invoke(() =>
                {
                    _mainWindow.MainFrame.Navigate(new LoginPage(_mainWindow));
                });
            });
        }

        private void RegisterEmployer()
        {
            // Проверка заполнения обязательных полей
            if (string.IsNullOrWhiteSpace(CompanyNameTextBox.Text))
            {
                ShowMessage("Введите название компании", true);
                CompanyNameTextBox.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(InnTextBox.Text))
            {
                ShowMessage("Введите ИНН", true);
                InnTextBox.Focus();
                return;
            }

            if (!Regex.IsMatch(InnTextBox.Text, @"^\d{10}$"))
            {
                ShowMessage("ИНН должен содержать 10 цифр", true);
                InnTextBox.Focus();
                InnTextBox.SelectAll();
                return;
            }

            if (string.IsNullOrWhiteSpace(CompanyEmailTextBox.Text))
            {
                ShowMessage("Введите Email", true);
                CompanyEmailTextBox.Focus();
                return;
            }

            if (!IsValidEmail(CompanyEmailTextBox.Text))
            {
                ShowMessage("Введите корректный Email", true);
                CompanyEmailTextBox.Focus();
                CompanyEmailTextBox.SelectAll();
                return;
            }

            string password = GetCompanyPassword();
            string confirmPassword = GetCompanyConfirmPassword();

            if (string.IsNullOrWhiteSpace(password))
            {
                ShowMessage("Введите пароль", true);
                FocusCompanyPassword();
                return;
            }

            if (password.Length < 6)
            {
                ShowMessage("Пароль должен содержать минимум 6 символов", true);
                FocusCompanyPassword();
                return;
            }

            if (password != confirmPassword)
            {
                ShowMessage("Пароли не совпадают", true);
                FocusCompanyConfirmPassword();
                return;
            }

            if (string.IsNullOrWhiteSpace(ContactPersonTextBox.Text))
            {
                ShowMessage("Введите контактное лицо", true);
                ContactPersonTextBox.Focus();
                return;
            }

            // Все проверки пройдены
            // Здесь должна быть логика сохранения в базу данных

            ShowMessage($"Работодатель {CompanyNameTextBox.Text} успешно зарегистрирован!", false);

            // Задержка перед переходом на страницу входа
            Task.Delay(1500).ContinueWith(_ =>
            {
                Dispatcher.Invoke(() =>
                {
                    _mainWindow.MainFrame.Navigate(new LoginPage(_mainWindow));
                });
            });
        }

        private string GetJobSeekerPassword()
        {
            if (_isPasswordVisible && _passwordTextBox != null)
                return _passwordTextBox.Text;
            else
                return PasswordBox.Password;
        }

        private string GetJobSeekerConfirmPassword()
        {
            if (_isConfirmPasswordVisible && _confirmPasswordTextBox != null)
                return _confirmPasswordTextBox.Text;
            else
                return ConfirmPasswordBox.Password;
        }

        private string GetCompanyPassword()
        {
            if (_isCompanyPasswordVisible && _companyPasswordTextBox != null)
                return _companyPasswordTextBox.Text;
            else
                return CompanyPasswordBox.Password;
        }

        private string GetCompanyConfirmPassword()
        {
            if (_isCompanyConfirmPasswordVisible && _companyConfirmPasswordTextBox != null)
                return _companyConfirmPasswordTextBox.Text;
            else
                return CompanyConfirmPasswordBox.Password;
        }

        private void FocusJobSeekerPassword()
        {
            if (_isPasswordVisible && _passwordTextBox != null)
                _passwordTextBox.Focus();
            else
                PasswordBox.Focus();
        }

        private void FocusJobSeekerConfirmPassword()
        {
            if (_isConfirmPasswordVisible && _confirmPasswordTextBox != null)
                _confirmPasswordTextBox.Focus();
            else
                ConfirmPasswordBox.Focus();
        }

        private void FocusCompanyPassword()
        {
            if (_isCompanyPasswordVisible && _companyPasswordTextBox != null)
                _companyPasswordTextBox.Focus();
            else
                CompanyPasswordBox.Focus();
        }

        private void FocusCompanyConfirmPassword()
        {
            if (_isCompanyConfirmPasswordVisible && _companyConfirmPasswordTextBox != null)
                _companyConfirmPasswordTextBox.Focus();
            else
                CompanyConfirmPasswordBox.Focus();
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private void ShowMessage(string message, bool isError)
        {
            MessageTextBlock.Text = message;
            MessageTextBlock.Visibility = Visibility.Visible;

            if (isError)
            {
                MessageTextBlock.Foreground = new SolidColorBrush(Color.FromRgb(244, 67, 54)); // Красный
            }
            else
            {
                MessageTextBlock.Foreground = new SolidColorBrush(Color.FromRgb(46, 125, 50)); // Зеленый
            }
        }

        private void HideMessage()
        {
            MessageTextBlock.Visibility = Visibility.Collapsed;
        }

        private void LoginRedirectButton_Click(object sender, RoutedEventArgs e)
        {
            _mainWindow.MainFrame.Navigate(new LoginPage(_mainWindow));
        }

        // Методы для кнопок показа/скрытия пароля
        // (Эти методы нужно будет подключить к кнопкам в XAML)

        private void ToggleJobSeekerPassword_Click(object sender, RoutedEventArgs e)
        {
            _isPasswordVisible = !_isPasswordVisible;
            UpdateJobSeekerPasswordToggle();
        }

        private void ToggleJobSeekerConfirmPassword_Click(object sender, RoutedEventArgs e)
        {
            _isConfirmPasswordVisible = !_isConfirmPasswordVisible;
            UpdateJobSeekerConfirmPasswordToggle();
        }

        private void ToggleCompanyPassword_Click(object sender, RoutedEventArgs e)
        {
            _isCompanyPasswordVisible = !_isCompanyPasswordVisible;
            UpdateCompanyPasswordToggle();
        }

        private void ToggleCompanyConfirmPassword_Click(object sender, RoutedEventArgs e)
        {
            _isCompanyConfirmPasswordVisible = !_isCompanyConfirmPasswordVisible;
            UpdateCompanyConfirmPasswordToggle();
        }

        private void UpdateJobSeekerPasswordToggle()
        {
            // Реализация аналогична LoginPage
            // Здесь нужно добавить логику замены PasswordBox на TextBox и обратно
        }

        private void UpdateJobSeekerConfirmPasswordToggle()
        {
            // Реализация аналогична LoginPage
        }

        private void UpdateCompanyPasswordToggle()
        {
            // Реализация аналогична LoginPage
        }

        private void UpdateCompanyConfirmPasswordToggle()
        {
            // Реализация аналогична LoginPage
        }
    }
}