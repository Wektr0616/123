﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro.Employer
{
    /// <summary>
    /// Логика взаимодействия для CreateVacancyPage.xaml
    /// </summary>
    public partial class CreateVacancyPage : Page
    {
        public CreateVacancyPage()
        {
            InitializeComponent();
            InitializeForm();
        }

        private void InitializeForm()
        {
            // Инициализация категорий
            var categories = new List<string>
            {
                "IT и программирование",
                "Маркетинг и продажи",
                "Бухгалтерия и финансы",
                "Производство",
                "Образование",
                "Медицина",
                "Строительство",
                "Транспорт и логистика",
                "Административный персонал",
                "Торговля",
                "Юриспруденция",
                "Дизайн",
                "Консалтинг",
                "HR и рекрутинг"
            };

            CategoryComboBox.ItemsSource = categories;
            CategoryComboBox.SelectedIndex = 0;

            // Инициализация типов занятости
            var employmentTypes = new List<string>
            {
                "Полная занятость",
                "Частичная занятость",
                "Удаленная работа",
                "Проектная работа",
                "Стажировка",
                "Вахтовый метод",
                "Гибкий график"
            };

            EmploymentTypeComboBox.ItemsSource = employmentTypes;
            EmploymentTypeComboBox.SelectedIndex = 0;

            // Инициализация опыта
            var experienceLevels = new List<string>
            {
                "Без опыта",
                "До 1 года",
                "1-3 года",
                "3-5 лет",
                "Более 5 лет",
                "Не имеет значения"
            };

            ExperienceComboBox.ItemsSource = experienceLevels;
            ExperienceComboBox.SelectedIndex = 5;
        }

        private void PreviewButton_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateRequiredFields())
            {
                return;
            }

            string previewText = $"=== ПРЕДПРОСМОТР ВАКАНСИИ ===\n\n" +
                               $"Должность: {PositionTextBox.Text}\n" +
                               $"Категория: {CategoryComboBox.SelectedItem}\n" +
                               $"Город: {CityTextBox.Text}\n" +
                               $"Зарплата: {SalaryFromTextBox.Text} - {SalaryToTextBox.Text} руб.\n" +
                               $"Тип занятости: {EmploymentTypeComboBox.SelectedItem}\n" +
                               $"Требуемый опыт: {ExperienceComboBox.SelectedItem}\n\n" +
                               $"=== ОПИСАНИЕ ===\n{DescriptionTextBox.Text}\n\n" +
                               $"=== ТРЕБОВАНИЯ ===\n{RequirementsTextBox.Text}\n\n" +
                               $"=== ОБЯЗАННОСТИ ===\n{ResponsibilitiesTextBox.Text}\n\n" +
                               $"=== УСЛОВИЯ ===\n{ConditionsTextBox.Text}";

            MessageBox.Show(previewText,
                          "Предпросмотр вакансии",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void SaveDraftButton_Click(object sender, RoutedEventArgs e)
        {
            if (ValidateRequiredFields())
            {
                // Сохранение черновика
                MessageBox.Show("Черновик вакансии сохранен. Вы можете продолжить редактирование позже.",
                              "Черновик сохранен",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        private void PublishButton_Click(object sender, RoutedEventArgs e)
        {
            if (ValidateRequiredFields())
            {
                var result = MessageBox.Show("Вы уверены, что хотите опубликовать вакансию?\n\n" +
                                           "После публикации вакансия станет видна соискателям.",
                                           "Публикация вакансии",
                                           MessageBoxButton.YesNo,
                                           MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    // Публикация вакансии
                    MessageBox.Show("Вакансия успешно опубликована!\n\n" +
                                  "Теперь она видна соискателям. Вы сможете управлять ей в разделе 'Мои вакансии'.",
                                  "Вакансия опубликована",
                                  MessageBoxButton.OK,
                                  MessageBoxImage.Information);

                    // Возврат на предыдущую страницу
                    // NavigationService?.GoBack();
                }
            }
        }

        private bool ValidateRequiredFields()
        {
            if (string.IsNullOrWhiteSpace(PositionTextBox.Text))
            {
                MessageBox.Show("Введите название должности",
                              "Обязательное поле",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                PositionTextBox.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(CityTextBox.Text))
            {
                MessageBox.Show("Введите город",
                              "Обязательное поле",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                CityTextBox.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(DescriptionTextBox.Text))
            {
                MessageBox.Show("Введите описание вакансии",
                              "Обязательное поле",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                DescriptionTextBox.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(RequirementsTextBox.Text))
            {
                MessageBox.Show("Введите требования к кандидату",
                              "Обязательное поле",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                RequirementsTextBox.Focus();
                return false;
            }

            return true;
        }

        // Загрузка данных для редактирования
        public void LoadForEdit(string vacancyId)
        {
            // В реальном приложении здесь будет загрузка данных вакансии из базы
            PositionTextBox.Text = "Разработчик C# / .NET";
            CategoryComboBox.SelectedIndex = 0;
            CityTextBox.Text = "Москва";
            SalaryFromTextBox.Text = "120000";
            SalaryToTextBox.Text = "180000";
            EmploymentTypeComboBox.SelectedIndex = 0;
            ExperienceComboBox.SelectedIndex = 2;
            DescriptionTextBox.Text = "Ищем опытного разработчика C# для работы над интересными проектами.";
            RequirementsTextBox.Text = "• Опыт работы с C# от 3 лет\n• Знание .NET Core, Entity Framework\n• Опыт работы с SQL Server\n• Умение работать в команде";
            ResponsibilitiesTextBox.Text = "• Разработка новых модулей системы\n• Поддержка существующего кода\n• Участие в code review";
            ConditionsTextBox.Text = "• Официальное трудоустройство\n• Гибкий график работы\n• Медицинская страховка\n• Корпоративное обучение";
        }
    }
}
