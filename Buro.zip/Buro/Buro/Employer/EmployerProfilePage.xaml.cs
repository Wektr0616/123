﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro.Employer
{
    /// <summary>
    /// Логика взаимодействия для EmployerProfilePage.xaml
    /// </summary>
    public partial class EmployerProfilePage : Page
    {
        private bool _isEditMode = false;

        public EmployerProfilePage()
        {
            InitializeComponent();
            LoadSampleData();
        }

        private void LoadSampleData()
        {
            // Загрузка тестовых данных
            CompanyNameTextBox.Text = "TechCorp Inc.";
            InnTextBox.Text = "1234567890";
            ContactPersonTextBox.Text = "Иванов Петр Сергеевич";
            EmailTextBox.Text = "hr@techcorp.com";
            PhoneTextBox.Text = "+7 (495) 123-45-67";
            CityTextBox.Text = "Москва";
            BusinessFieldTextBox.Text = "IT-разработка, консалтинг";
            EmployeesCountTextBox.Text = "150";
            WebsiteTextBox.Text = "www.techcorp.com";
            DescriptionTextBox.Text = "Ведущая IT-компания, специализирующаяся на разработке корпоративного программного обеспечения. Основана в 2010 году. Работаем с клиентами по всему миру.";
        }

        private void EditProfileButton_Click(object sender, RoutedEventArgs e)
        {
            _isEditMode = true;
            EnableEditMode();
        }

        private void EnableEditMode()
        {
            // Разрешаем редактирование полей
            CompanyNameTextBox.IsReadOnly = false;
            InnTextBox.IsReadOnly = false;
            ContactPersonTextBox.IsReadOnly = false;
            EmailTextBox.IsReadOnly = false;
            PhoneTextBox.IsReadOnly = false;
            CityTextBox.IsReadOnly = false;
            BusinessFieldTextBox.IsReadOnly = false;
            EmployeesCountTextBox.IsReadOnly = false;
            WebsiteTextBox.IsReadOnly = false;
            DescriptionTextBox.IsReadOnly = false;

            // Показываем кнопки сохранения/отмены
            EditButtonsPanel.Visibility = Visibility.Visible;
            EditProfileButton.Visibility = Visibility.Collapsed;
        }

        private void DisableEditMode()
        {
            // Запрещаем редактирование полей
            CompanyNameTextBox.IsReadOnly = true;
            InnTextBox.IsReadOnly = true;
            ContactPersonTextBox.IsReadOnly = true;
            EmailTextBox.IsReadOnly = true;
            PhoneTextBox.IsReadOnly = true;
            CityTextBox.IsReadOnly = true;
            BusinessFieldTextBox.IsReadOnly = true;
            EmployeesCountTextBox.IsReadOnly = true;
            WebsiteTextBox.IsReadOnly = true;
            DescriptionTextBox.IsReadOnly = true;

            // Скрываем кнопки сохранения/отмены
            EditButtonsPanel.Visibility = Visibility.Collapsed;
            EditProfileButton.Visibility = Visibility.Visible;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (ValidateForm())
            {
                // Сохранение данных
                _isEditMode = false;
                DisableEditMode();

                MessageBox.Show("Данные компании успешно сохранены!",
                              "Сохранено",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        private bool ValidateForm()
        {
            if (string.IsNullOrWhiteSpace(CompanyNameTextBox.Text))
            {
                MessageBox.Show("Введите название компании",
                              "Ошибка",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                CompanyNameTextBox.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(InnTextBox.Text) || InnTextBox.Text.Length != 10)
            {
                MessageBox.Show("ИНН должен содержать 10 цифр",
                              "Ошибка",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                InnTextBox.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(ContactPersonTextBox.Text))
            {
                MessageBox.Show("Введите контактное лицо",
                              "Ошибка",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                ContactPersonTextBox.Focus();
                return false;
            }

            return true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            _isEditMode = false;
            DisableEditMode();
            LoadSampleData(); // Возвращаем исходные данные
        }
    }
}