﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro.Employer
{
    /// <summary>
    /// Логика взаимодействия для MyVacanciesPage.xaml
    /// </summary>
    public partial class MyVacanciesPage : Page
    {
        public MyVacanciesPage()
        {
            InitializeComponent();
        }

        private void CreateNewButton_Click(object sender, RoutedEventArgs e)
        {
            // Переход на страницу создания вакансии
            // NavigationService?.Navigate(new CreateVacancyPage());
            MessageBox.Show("Переход на страницу создания вакансии",
                          "Создание вакансии",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void ViewButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Просмотр деталей вакансии",
                          "Детали вакансии",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Редактирование вакансии",
                          "Редактирование",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Вы уверены, что хотите закрыть эту вакансию?",
                                       "Закрытие вакансии",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Вакансия закрыта. Новые отклики не принимаются.",
                              "Вакансия закрыта",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        private void StatsButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Статистика по вакансии:\n\n" +
                          "• Всего просмотров: 245\n" +
                          "• Всего откликов: 12\n" +
                          "• Подходящих кандидатов: 5\n" +
                          "• Приглашено на собеседование: 3\n" +
                          "• Принято на работу: 1",
                          "Статистика вакансии",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void ReopenButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Вы уверены, что хотите открыть эту вакансию заново?",
                                       "Открытие вакансии",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Вакансия открыта. Теперь принимаются новые отклики.",
                              "Вакансия открыта",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }
    }
}