﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro.Employer
{
    /// <summary>
    /// Логика взаимодействия для SearchCandidatesPage.xaml
    /// </summary>
    public partial class SearchCandidatesPage : Page
    {
        public SearchCandidatesPage()
        {
            InitializeComponent();
            InitializeFilters();
            LoadSampleData();
        }

        private void InitializeFilters()
        {
            // Инициализация городов
            var cities = new List<string>
            {
                "Все города",
                "Москва",
                "Санкт-Петербург",
                "Новосибирск",
                "Екатеринбург",
                "Казань",
                "Нижний Новгород",
                "Челябинск",
                "Самара",
                "Омск"
            };

            CityComboBox.ItemsSource = cities;
            CityComboBox.SelectedIndex = 0;

            // Инициализация профессий
            var professions = new List<string>
            {
                "Все профессии",
                "Разработчик C#",
                "Java разработчик",
                "Frontend разработчик",
                "Backend разработчик",
                "Менеджер по продажам",
                "Маркетолог",
                "Бухгалтер",
                "Менеджер проекта",
                "Дизайнер",
                "Системный администратор",
                "Тестировщик"
            };

            ProfessionComboBox.ItemsSource = professions;
            ProfessionComboBox.SelectedIndex = 0;

            // Инициализация опыта
            var experienceLevels = new List<string>
            {
                "Любой опыт",
                "Без опыта",
                "До 1 года",
                "1-3 года",
                "3-5 лет",
                "Более 5 лет"
            };

            ExperienceComboBox.ItemsSource = experienceLevels;
            ExperienceComboBox.SelectedIndex = 0;

            // Инициализация типов занятости
            var employmentTypes = new List<string>
            {
                "Любой тип",
                "Полная занятость",
                "Частичная занятость",
                "Удаленная работа",
                "Проектная работа"
            };

            EmploymentTypeComboBox.ItemsSource = employmentTypes;
            EmploymentTypeComboBox.SelectedIndex = 0;
        }

        private void LoadSampleData()
        {
            // Загрузка тестовых данных
            ResultsCountText.Text = "Найдено кандидатов: 8";
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            PerformSearch();
        }

        private void ClearFiltersButton_Click(object sender, RoutedEventArgs e)
        {
            // Сброс фильтров
            SearchTextBox.Clear();
            CityComboBox.SelectedIndex = 0;
            ProfessionComboBox.SelectedIndex = 0;
            ExperienceComboBox.SelectedIndex = 0;
            SalaryToTextBox.Clear();
            EmploymentTypeComboBox.SelectedIndex = 0;

            // Выполнение поиска со сброшенными фильтрами
            PerformSearch();
        }

        private void PerformSearch()
        {
            string searchText = SearchTextBox.Text.Trim();
            string city = CityComboBox.SelectedItem as string;
            string profession = ProfessionComboBox.SelectedItem as string;
            string experience = ExperienceComboBox.SelectedItem as string;
            string salaryText = SalaryToTextBox.Text.Trim();
            string employmentType = EmploymentTypeComboBox.SelectedItem as string;

            // Здесь должна быть логика поиска в базе данных
            // Временная заглушка

            int results = 8; // Примерное количество результатов
            ResultsCountText.Text = $"Найдено кандидатов: {results}";

            MessageBox.Show($"Поиск кандидатов:\n" +
                          $"Текст: {searchText}\n" +
                          $"Город: {city}\n" +
                          $"Профессия: {profession}\n" +
                          $"Опыт: {experience}\n" +
                          $"Зарплата до: {salaryText}\n" +
                          $"Тип занятости: {employmentType}",
                          "Результаты поиска",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void ViewProfileButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Здесь будет подробный профиль кандидата",
                          "Профиль кандидата",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void InviteButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Вы хотите пригласить этого кандидата?\n\n" +
                                       "Кандидат получит уведомление о вашем предложении.",
                                       "Приглашение кандидата",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Приглашение отправлено кандидату!",
                              "Успешно",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }
    }
}