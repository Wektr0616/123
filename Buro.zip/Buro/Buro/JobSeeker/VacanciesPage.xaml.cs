﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro.JobSeeker
{
    /// <summary>
    /// Логика взаимодействия для VacanciesPage.xaml
    /// </summary>
    public partial class VacanciesPage : Page
    {
        public VacanciesPage()
        {
            InitializeComponent();
            InitializeFilters();
            LoadSampleData();
        }

        private void InitializeFilters()
        {
            // Инициализация городов
            var cities = new List<string>
            {
                "Все города",
                "Москва",
                "Санкт-Петербург",
                "Новосибирск",
                "Екатеринбург",
                "Казань",
                "Нижний Новгород",
                "Челябинск",
                "Самара",
                "Омск",
                "Ростов-на-Дону",
                "Уфа",
                "Красноярск",
                "Воронеж",
                "Пермь"
            };

            CityComboBox.ItemsSource = cities;
            CityComboBox.SelectedIndex = 0;

            // Инициализация категорий
            var categories = new List<string>
            {
                "Все категории",
                "IT и программирование",
                "Маркетинг и продажи",
                "Бухгалтерия и финансы",
                "Производство",
                "Образование",
                "Медицина",
                "Строительство",
                "Транспорт и логистика",
                "Административный персонал",
                "Торговля",
                "Юриспруденция",
                "Дизайн",
                "Консалтинг"
            };

            CategoryComboBox.ItemsSource = categories;
            CategoryComboBox.SelectedIndex = 0;

            // Инициализация типов занятости
            var employmentTypes = new List<string>
            {
                "Любой",
                "Полная занятость",
                "Частичная занятость",
                "Удаленная работа",
                "Проектная работа",
                "Стажировка",
                "Волонтерство"
            };

            EmploymentTypeComboBox.ItemsSource = employmentTypes;
            EmploymentTypeComboBox.SelectedIndex = 0;

            // Инициализация опыта
            var experienceLevels = new List<string>
            {
                "Любой",
                "Без опыта",
                "До 1 года",
                "1-3 года",
                "3-5 лет",
                "Более 5 лет"
            };

            ExperienceComboBox.ItemsSource = experienceLevels;
            ExperienceComboBox.SelectedIndex = 0;
        }

        private void LoadSampleData()
        {
            // Загрузка тестовых данных
            ResultsCountText.Text = "Найдено вакансий: 15";
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            PerformSearch();
        }

        private void ClearFiltersButton_Click(object sender, RoutedEventArgs e)
        {
            // Сброс фильтров
            SearchTextBox.Clear();
            CityComboBox.SelectedIndex = 0;
            SalaryFromTextBox.Clear();
            CategoryComboBox.SelectedIndex = 0;
            EmploymentTypeComboBox.SelectedIndex = 0;
            ExperienceComboBox.SelectedIndex = 0;

            // Выполнение поиска со сброшенными фильтрами
            PerformSearch();
        }

        private void PerformSearch()
        {
            string searchText = SearchTextBox.Text.Trim();
            string city = CityComboBox.SelectedItem as string;
            string salaryText = SalaryFromTextBox.Text.Trim();
            string category = CategoryComboBox.SelectedItem as string;
            string employmentType = EmploymentTypeComboBox.SelectedItem as string;
            string experience = ExperienceComboBox.SelectedItem as string;

            // Здесь должна быть логика поиска в базе данных
            // Временная заглушка

            int results = 15; // Примерное количество результатов
            ResultsCountText.Text = $"Найдено вакансий: {results}";

            MessageBox.Show($"Поиск выполнен:\n" +
                          $"Текст: {searchText}\n" +
                          $"Город: {city}\n" +
                          $"Зарплата от: {salaryText}\n" +
                          $"Категория: {category}\n" +
                          $"Тип занятости: {employmentType}\n" +
                          $"Опыт: {experience}",
                          "Результаты поиска",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void ViewDetailsButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Здесь будет подробная информация о вакансии",
                          "Подробности вакансии",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void ApplyButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Вы уверены, что хотите откликнуться на эту вакансию?",
                                       "Отклик на вакансию",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Ваш отклик успешно отправлен! Работодатель получит уведомление.",
                              "Успешно",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        // Метод для обработки Enter в поле поиска
        private void SearchTextBox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                PerformSearch();
            }
        }
    }
}