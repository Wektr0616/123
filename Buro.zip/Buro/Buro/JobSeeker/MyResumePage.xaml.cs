﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro.JobSeeker
{
    /// <summary>
    /// Логика взаимодействия для MyResumePage.xaml
    /// </summary>
    public partial class MyResumePage : Page
    {
        private bool _isResumeActive = true;
        private bool _isResumeSaved = false;

        public MyResumePage()
        {
            InitializeComponent();
            InitializeForm();
            LoadSampleData();
        }

        private void InitializeForm()
        {
            // Инициализация ComboBox для типа занятости
            var employmentTypes = new List<string>
            {
                "Полная занятость",
                "Частичная занятость",
                "Удаленная работа",
                "Проектная работа",
                "Стажировка",
                "Гибкий график",
                "Вахтовый метод"
            };

            EmploymentTypeComboBox.ItemsSource = employmentTypes;
            EmploymentTypeComboBox.SelectedIndex = 0;

            // Настройка плейсхолдеров
            SetupPlaceholders();
        }

        private void SetupPlaceholders()
        {
            // Плейсхолдеры уже настроены в XAML через стили
            // Здесь можно добавить дополнительную логику при необходимости
        }

        private void LoadSampleData()
        {
            // Загрузка тестовых данных
            FullNameTextBox.Text = "Иванов Иван Иванович";
            EmailTextBox.Text = "ivanov@example.com";
            PhoneTextBox.Text = "+7 (999) 123-45-67";
            CityTextBox.Text = "Москва";
            ProfessionTextBox.Text = "Разработчик C# / .NET";
            ExperienceTextBox.Text = "• ООО \"Технологии Будущего\" (2020-настоящее время)\n  Разработчик C#, участие в создании ERP-системы\n\n• ООО \"СофтДев\" (2018-2020)\n  Junior разработчик, поддержка корпоративных приложений";
            EducationTextBox.Text = "• Московский технический университет (2014-2018)\n  Факультет информатики и вычислительной техники\n  Специальность: Программная инженерия\n  Диплом с отличием";
            SkillsTextBox.Text = "• C#, .NET Framework/.NET Core\n• ASP.NET MVC, Web API\n• Entity Framework, SQL Server\n• WPF, XAML\n• Git, Azure DevOps\n• ООП, паттерны проектирования\n• Английский язык: B2";
            SalaryTextBox.Text = "150000";
            EmploymentTypeComboBox.SelectedIndex = 0;
        }

        private void ToggleActiveButton_Click(object sender, RoutedEventArgs e)
        {
            _isResumeActive = !_isResumeActive;

            if (_isResumeActive)
            {
                ResumeStatusText.Text = "Анкета активна";
                ResumeStatusText.Foreground = new SolidColorBrush(Color.FromRgb(76, 175, 80)); // Зеленый
                ToggleActiveButton.Content = "Деактивировать";
                ToggleActiveButton.Foreground = new SolidColorBrush(Color.FromRgb(244, 67, 54)); // Красный
                ToggleActiveButton.BorderBrush = new SolidColorBrush(Color.FromRgb(244, 67, 54));

                MessageBox.Show("Анкета активирована. Теперь работодатели могут видеть вашу анкету.",
                              "Анкета активирована",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
            else
            {
                ResumeStatusText.Text = "Анкета неактивна";
                ResumeStatusText.Foreground = new SolidColorBrush(Color.FromRgb(244, 67, 54)); // Красный
                ToggleActiveButton.Content = "Активировать";
                ToggleActiveButton.Foreground = new SolidColorBrush(Color.FromRgb(76, 175, 80)); // Зеленый
                ToggleActiveButton.BorderBrush = new SolidColorBrush(Color.FromRgb(76, 175, 80));

                MessageBox.Show("Анкета деактивирована. Работодатели больше не видят вашу анкету.",
                              "Анкета деактивирована",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (ValidateForm())
            {
                // Здесь должна быть логика сохранения в базу данных
                SaveResumeToDatabase();

                _isResumeSaved = true;

                MessageBox.Show("Анкета успешно сохранена!\n\n" +
                              "Теперь ваша анкета видна работодателям и вы можете:\n" +
                              "1. Получать предложения от работодателей\n" +
                              "2. Быстро откликаться на вакансии\n" +
                              "3. Участвовать в подборе персонала",
                              "Анкета сохранена",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        private bool ValidateForm()
        {
            // Проверка обязательных полей
            if (string.IsNullOrWhiteSpace(FullNameTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, укажите ваше ФИО",
                              "Ошибка валидации",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                FullNameTextBox.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(EmailTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, укажите ваш email",
                              "Ошибка валидации",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                EmailTextBox.Focus();
                return false;
            }

            if (!IsValidEmail(EmailTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, укажите корректный email",
                              "Ошибка валидации",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                EmailTextBox.Focus();
                EmailTextBox.SelectAll();
                return false;
            }

            if (string.IsNullOrWhiteSpace(ProfessionTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, укажите вашу профессию",
                              "Ошибка валидации",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                ProfessionTextBox.Focus();
                return false;
            }

            return true;
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private void SaveResumeToDatabase()
        {
            // Здесь должна быть логика сохранения в базу данных
            // Временная заглушка

            var resumeData = new
            {
                FullName = FullNameTextBox.Text,
                Email = EmailTextBox.Text,
                Phone = PhoneTextBox.Text,
                City = CityTextBox.Text,
                Profession = ProfessionTextBox.Text,
                Experience = ExperienceTextBox.Text,
                Education = EducationTextBox.Text,
                Skills = SkillsTextBox.Text,
                Salary = SalaryTextBox.Text,
                EmploymentType = EmploymentTypeComboBox.SelectedItem as string,
                IsActive = _isResumeActive,
                LastUpdated = DateTime.Now
            };

            // В реальном приложении здесь будет вызов метода для сохранения в БД
            // Например: Database.SaveResume(resumeData);
        }

        private void PreviewButton_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateForm())
            {
                return;
            }

            // Создаем предпросмотр анкеты
            string previewText = $"=== ПРЕДПРОСМОТР АНКЕТЫ ===\n\n" +
                               $"ФИО: {FullNameTextBox.Text}\n" +
                               $"Email: {EmailTextBox.Text}\n" +
                               $"Телефон: {(string.IsNullOrWhiteSpace(PhoneTextBox.Text) ? "Не указан" : PhoneTextBox.Text)}\n" +
                               $"Город: {(string.IsNullOrWhiteSpace(CityTextBox.Text) ? "Не указан" : CityTextBox.Text)}\n" +
                               $"Профессия: {ProfessionTextBox.Text}\n" +
                               $"Тип занятости: {EmploymentTypeComboBox.SelectedItem}\n" +
                               $"Желаемая зарплата: {(string.IsNullOrWhiteSpace(SalaryTextBox.Text) ? "Не указана" : SalaryTextBox.Text + " руб.")}\n\n" +
                               $"=== ОПЫТ РАБОТЫ ===\n{ExperienceTextBox.Text}\n\n" +
                               $"=== ОБРАЗОВАНИЕ ===\n{EducationTextBox.Text}\n\n" +
                               $"=== НАВЫКИ ===\n{SkillsTextBox.Text}\n\n" +
                               $"=== СТАТУС ===\n{(_isResumeActive ? "✅ Активна (видна работодателям)" : "⛔ Неактивна (скрыта от работодателей)")}";

            MessageBox.Show(previewText,
                          "Предпросмотр анкеты",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        // Методы для очистки полей
        private void ClearForm()
        {
            FullNameTextBox.Clear();
            EmailTextBox.Clear();
            PhoneTextBox.Clear();
            CityTextBox.Clear();
            ProfessionTextBox.Clear();
            ExperienceTextBox.Clear();
            EducationTextBox.Clear();
            SkillsTextBox.Clear();
            SalaryTextBox.Clear();
            EmploymentTypeComboBox.SelectedIndex = 0;
        }

        // Метод для копирования данных из профиля
        public void LoadFromProfile(JobSeekerProfilePage profilePage)
        {
            // В реальном приложении здесь будет загрузка данных из профиля пользователя
            // Например:
            // FullNameTextBox.Text = profilePage.FullName;
            // EmailTextBox.Text = profilePage.Email;
            // и т.д.
        }

        // Метод для проверки заполненности анкеты
        public bool IsResumeComplete()
        {
            return !string.IsNullOrWhiteSpace(FullNameTextBox.Text) &&
                   !string.IsNullOrWhiteSpace(EmailTextBox.Text) &&
                   !string.IsNullOrWhiteSpace(ProfessionTextBox.Text);
        }

        // Метод для получения статуса анкеты
        public string GetResumeStatus()
        {
            if (!IsResumeComplete())
                return "Не заполнена";

            return _isResumeActive ? "Активна" : "Неактивна";
        }
    }
}