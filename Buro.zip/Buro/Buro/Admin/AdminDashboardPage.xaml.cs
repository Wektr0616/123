﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro.Admin
{
    /// <summary>
    /// Логика взаимодействия для AdminDashboardPage.xaml
    /// </summary>
    public partial class AdminDashboardPage : Page
    {
        public AdminDashboardPage()
        {
            InitializeComponent();
        }

        private void AddUserButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Здесь будет форма добавления нового пользователя",
                          "Добавление пользователя",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void CheckVacanciesButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Переход на страницу проверки вакансий",
                          "Проверка вакансий",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void CreateReportButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Создание отчета о работе системы",
                          "Создание отчета",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void RefreshCacheButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Кэш системы обновлен",
                          "Обновление кэша",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }
    }
}
