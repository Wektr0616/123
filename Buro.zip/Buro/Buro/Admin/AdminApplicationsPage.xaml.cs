﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro.Admin
{
    /// <summary>
    /// Логика взаимодействия для AdminApplicationsPage.xaml
    /// </summary>
    public partial class AdminApplicationsPage : Page
    {
        public AdminApplicationsPage()
        {
            InitializeComponent();
            InitializeFilters();
        }

        private void InitializeFilters()
        {
            // Фильтр статусов
            var statuses = new List<string>
            {
                "Все статусы",
                "На рассмотрении",
                "Принятые",
                "Отклоненные",
                "Приглашены на собеседование",
                "Архивные"
            };

            StatusFilterComboBox.ItemsSource = statuses;
            StatusFilterComboBox.SelectedIndex = 0;

            // Фильтр по дате
            var dateFilters = new List<string>
            {
                "За все время",
                "Сегодня",
                "За неделю",
                "За месяц",
                "За 3 месяца"
            };

            DateFilterComboBox.ItemsSource = dateFilters;
            DateFilterComboBox.SelectedIndex = 0;
        }

        private void StatisticsButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Статистика по заявкам:\n\n" +
                          "• Всего заявок: 156\n" +
                          "• На рассмотрении: 24\n" +
                          "• Принято: 45\n" +
                          "• Отклонено: 32\n" +
                          "• Приглашено на собеседование: 18\n" +
                          "• Трудоустроено: 8",
                          "Статистика заявок",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void ProcessAllButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Обработать все заявки со статусом 'На рассмотрении'?\n\n" +
                                       "Это действие может занять некоторое время.",
                                       "Массовая обработка",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Все заявки успешно обработаны!",
                              "Обработка завершена",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        private void ViewApplicationButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Просмотр полной информации о заявке:\n\n" +
                          "• Данные соискателя\n" +
                          "• Резюме и сопроводительное письмо\n" +
                          "• Информация о вакансии\n" +
                          "• История переписки\n" +
                          "• Комментарии работодателя",
                          "Просмотр заявки",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void AcceptApplicationButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Принять эту заявку?\n\n" +
                                       "Соискатель получит уведомление о принятии заявки.",
                                       "Принятие заявки",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Заявка принята. Соискатель уведомлен.",
                              "Заявка принята",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        private void RejectApplicationButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Отклонить эту заявку?\n\n" +
                                       "Соискатель получит уведомление об отказе.",
                                       "Отклонение заявки",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Заявка отклонена. Соискатель уведомлен.",
                              "Заявка отклонена",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        private void ContactButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Связь с соискателем:\n\n" +
                          "• Отправка сообщения\n" +
                          "• Назначение собеседования\n" +
                          "• Обновление статуса",
                          "Связь с соискателем",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void StatsButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Статистика по конкретной заявке:\n\n" +
                          "• Дата подачи: 09.01.2024\n" +
                          "• Время рассмотрения: 2 дня\n" +
                          "• Количество просмотров: 3\n" +
                          "• Статус: Принята\n" +
                          "• Следующий шаг: Собеседование",
                          "Статистика заявки",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }
    }
}
