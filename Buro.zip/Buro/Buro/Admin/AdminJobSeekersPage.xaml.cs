﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro.Admin
{
    /// <summary>
    /// Логика взаимодействия для AdminJobSeekersPage.xaml
    /// </summary>
    public partial class AdminJobSeekersPage : Page
    {
        public AdminJobSeekersPage()
        {
            InitializeComponent();
            InitializeFilters();
        }

        private void InitializeFilters()
        {
            // Статусы
            var statuses = new List<string>
            {
                "Все статусы",
                "Активен",
                "Неактивен",
                "Заблокирован",
                "В поиске"
            };

            StatusFilterComboBox.ItemsSource = statuses;
            StatusFilterComboBox.SelectedIndex = 0;

            // Опыт
            var experiences = new List<string>
            {
                "Любой опыт",
                "Без опыта",
                "До 1 года",
                "1-3 года",
                "3-5 лет",
                "Более 5 лет"
            };

            ExperienceFilterComboBox.ItemsSource = experiences;
            ExperienceFilterComboBox.SelectedIndex = 0;
        }

        private void ExportButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Экспорт данных соискателей:\n\n" +
                          "1. Выберите формат (Excel, CSV, PDF)\n" +
                          "2. Выберите поля для экспорта\n" +
                          "3. Начните экспорт",
                          "Экспорт данных",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void ViewProfileButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Просмотр полного профиля соискателя:\n\n" +
                          "• Личная информация\n" +
                          "• Профессиональные данные\n" +
                          "• История откликов\n" +
                          "• Статистика активности",
                          "Профиль соискателя",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void ViewResumeButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Просмотр резюме соискателя",
                          "Резюме",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Редактирование данных соискателя:\n\n" +
                          "• Изменение личных данных\n" +
                          "• Редактирование резюме\n" +
                          "• Изменение статуса\n" +
                          "• Настройка видимости",
                          "Редактирование",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Удалить этого соискателя?\n\n" +
                                       "Все данные будут удалены безвозвратно.",
                                       "Удаление",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Соискатель удален успешно.",
                              "Удаление завершено",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }
    }
}