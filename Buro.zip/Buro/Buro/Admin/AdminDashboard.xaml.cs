﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Navigation;

namespace Buro.Admin
{
    /// <summary>
    /// Логика взаимодействия для AdminDashboard.xaml
    /// </summary>
    public partial class AdminDashboard : Page
    {
        private MainWindow _mainWindow;
        private Button _activeButton;

        public AdminDashboard(MainWindow mainWindow, string adminName)
        {
            InitializeComponent();
            _mainWindow = mainWindow;

            // Устанавливаем имя администратора
            AdminNameText.Text = adminName;

            // Инициализация
            InitializeDashboard();
        }

        private void InitializeDashboard()
        {
            // Загружаем первую страницу по умолчанию
            LoadDashboardPage();

            // Устанавливаем активную кнопку
            SetActiveButton(DashboardButton);
        }

        private void SetActiveButton(Button button)
        {
            // Сбрасываем предыдущую активную кнопку
            if (_activeButton != null)
            {
                ResetButtonStyle(_activeButton);
            }

            // Устанавливаем новую активную кнопку
            _activeButton = button;
            ApplyActiveButtonStyle(_activeButton);
        }

        private void ResetButtonStyle(Button button)
        {
            button.Background = Brushes.Transparent;
            button.Foreground = new SolidColorBrush(Color.FromRgb(204, 204, 204));
        }

        private void ApplyActiveButtonStyle(Button button)
        {
            button.Background = new SolidColorBrush(Color.FromRgb(45, 45, 45));
            button.Foreground = Brushes.White;
        }

        private void LoadDashboardPage()
        {
            ContentFrame.Navigate(new AdminDashboardPage());
        }

        private void DashboardButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new AdminDashboardPage());
            SetActiveButton(DashboardButton);
        }

        private void UsersButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new AdminUsersPage());
            SetActiveButton(UsersButton);
        }

        private void JobSeekersButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new AdminJobSeekersPage());
            SetActiveButton(JobSeekersButton);
        }

        private void EmployersButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new AdminEmployersPage());
            SetActiveButton(EmployersButton);
        }

        private void VacanciesButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new AdminVacanciesPage());
            SetActiveButton(VacanciesButton);
        }

        private void ApplicationsButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new AdminApplicationsPage());
            SetActiveButton(ApplicationsButton);
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Вы уверены, что хотите выйти из панели администратора?",
                                       "Выход",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                _mainWindow.NavigateToMainPage();
            }
        }
    }
}
